package lesson3.labs.prob2;

public class Apartments {
	private int rent; // Apartment has rent.
	
	Apartments(int rent){
		this.rent = rent;
	}
	
	public int getRent(){
		return rent;
	}
	
	public void setRent(int rent){
		this.rent = rent;
	}

}
