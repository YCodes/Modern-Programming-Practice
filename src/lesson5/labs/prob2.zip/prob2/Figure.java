package lesson5.labs.prob2;

public interface Figure {
	public double computeArea();
}
